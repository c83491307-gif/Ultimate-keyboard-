# Creazzy Keyboard — Android WebView package

This project packages the supplied Arabic-first `index.html` into an installable Android application using a native Kotlin WebView shell. The approach follows the common open-source Android WebView-template pattern (see [ASTRALLIBERTAD/web-app](https://github.com/ASTRALLIBERTAD/web-app)) and uses AndroidX WebKit's `WebViewAssetLoader` to serve bundled files from a local HTTPS-style origin.

## Build an APK with GitHub Actions

1. Create a new GitHub repository or use a repository you can push to.
2. Upload the **contents of this folder** to the repository root (not the outer ZIP folder).
3. Open **Actions → Build Creazzy Keyboard APK**. It runs on pushes and can also be started with **Run workflow**.
4. When the workflow succeeds, open its run, scroll to **Artifacts**, and download `CreazzyKeyboard-debug-APK`.
5. Extract the artifact ZIP and install `app-debug.apk` on Android. Android may ask you to allow installation from that source.

## Build locally

Requirements: JDK 17, Android SDK platform 35, build-tools 35.0.0, and Gradle 8.9.

```bash
gradle --no-daemon assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Important product limitation

This package is an Android **companion app** that displays the HTML interface. It is not yet a system-wide Android keyboard and will not appear in Android's keyboard picker. A system keyboard requires a separate native `InputMethodService` module. The original native starter can be developed alongside this wrapper as the next phase.

## Privacy / permissions

The wrapper declares no `INTERNET` permission and does not load remote pages. JavaScript and DOM storage are enabled for the bundled HTML; file/content URL access is disabled. Data stored through browser storage stays in this app's private WebView data area.

## Source inspiration and license

The WebView packaging approach is a general Android pattern. See the referenced template for its own license and source details. The included HTML is the project-specific UI supplied for this build package.
